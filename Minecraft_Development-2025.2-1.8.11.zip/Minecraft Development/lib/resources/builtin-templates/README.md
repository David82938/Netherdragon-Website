<p align="center"><a href="https://minecraftdev.org/"><img src="https://minecraftdev.org/assets/icon.svg" height="120" alt="logo"/></a></p>

Minecraft Development for IntelliJ - Templates
==============================================

## Info and Documentation
<a href="https://discord.gg/j6UNcfr"><img src="https://i.imgur.com/JXu9C1G.png" height="48px"></img></a>

This repository is part of the Minecraft Development for IntelliJ project.

This contains the default templates for this plugin.

For more information, please visit [https://mcdev.io](https://mcdev.io).

## Usage
You simply need to install the plugin Minecraft Development for IntelliJ on your instance of Jetbrains IntelliJ Idea.

For more information about this plugin's installation, please see [this explanation](https://github.com/minecraft-dev/MinecraftDev?tab=readme-ov-file#installation).

## Testing
If you want to modify these templates or create your own, please see [https://mcdev.io/docs/creating-creator-templates/](https://mcdev.io/docs/creating-creator-templates/) for information about this.

You can either choose to host your modifications on a GitHub repository or on your local machine. If you choose to host it on your own machine, please select "local" instead of "remote" (as explained in the documentation).

License
-------

This project is licensed under [LGPLv3.0-only](license.txt).

Supported Platforms
-------------------
- [![Spigot Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Spigot.png?raw=true) **Spigot**](https://spigotmc.org/) ([![Paper Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Paper.png?raw=true) Paper](https://papermc.io/))
- [![Sponge Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Sponge_dark.png?raw=true) **Sponge**](https://www.spongepowered.org/)
- [![Architectury Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Architectury.png?raw=true) **Architectury**](https://github.com/architectury/architectury-api)
- [![Forge Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Forge.png?raw=true) **Minecraft Forge**](https://forums.minecraftforge.net/)
- <a href="https://neoforged.net/"><img src="https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/NeoForge.png?raw=true" width="16" height="16"/> <b>Neoforge</b><a/>
- [![Fabric Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Fabric.png?raw=true) **Fabric**](https://fabricmc.net)
- [![Mixins Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Mixins_dark.png?raw=true) **Mixins**](https://github.com/SpongePowered/Mixin)
- [![BungeeCord Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/BungeeCord.png?raw=true) **BungeeCord**](https://www.spigotmc.org/wiki/bungeecord/) ([![Waterfall Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Waterfall.png?raw=true) Waterfall](https://github.com/PaperMC/Waterfall))
- [![Velocity Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Velocity.png?raw=true) **Velocity**](https://velocitypowered.com/)
- [![Adventure Icon](https://github.com/minecraft-dev/MinecraftDev/blob/dev/src/main/resources/assets/icons/platform/Adventure.png?raw=true) **Adventure**](https://kyori.net/)
